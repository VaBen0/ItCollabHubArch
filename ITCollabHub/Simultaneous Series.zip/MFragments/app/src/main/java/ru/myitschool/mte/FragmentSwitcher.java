package ru.myitschool.mte;

import android.annotation.SuppressLint;

import androidx.fragment.app.Fragment;
import androidx.fragment.app.FragmentManager;
import androidx.fragment.app.FragmentTransaction;

public class FragmentSwitcher extends Thread{
    private static final int THREAD_DELAY = 3000;
    private boolean fragmentType = false;
    private boolean runnable = true;
    private final Fragment fragmentOne;
    private final Fragment fragmentTwo;
    private final FragmentManager switcher;

    public FragmentSwitcher(Fragment fragmentOne, Fragment fragmentTwo, FragmentManager switcher){
        this.fragmentOne = fragmentOne;
        this.fragmentTwo = fragmentTwo;
        this.switcher = switcher;
    }
    @Override
    public void run() {
        super.run();
        while(runnable){
            if(!switcher.isDestroyed()){
                FragmentTransaction transaction = switcher.beginTransaction();
                if(!fragmentType){
                    transaction
                            .replace(R.id.output_fragment, fragmentOne)
                            .commit();
                    fragmentType = true;
                }
                else{
                    transaction
                            .replace(R.id.output_fragment, fragmentTwo)
                            .commit();
                    fragmentType = false;
                }
            }

            try {
                Thread.sleep(THREAD_DELAY);
            } catch (InterruptedException e) {
                throw new RuntimeException(e);
            }
        }
    }

    public void desable(){
        runnable = false;
    }
}
